import { useRef, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Sphere, MeshDistortMaterial, useTexture, Environment } from '@react-three/drei';
import * as THREE from 'three';
import gsap from 'gsap';

// Floating sphere component with distortion effect
const FloatingSphere = ({ position, color, speed, distort, scale }: { 
  position: [number, number, number], 
  color: string, 
  speed: number,
  distort: number,
  scale: number
}) => {
  const meshRef = useRef<THREE.Mesh>(null);
  
  // Animate the sphere on each frame
  useFrame((state) => {
    if (!meshRef.current) return;
    
    // Gentle floating motion
    meshRef.current.position.y += Math.sin(state.clock.elapsedTime * speed) * 0.002;
    meshRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.3) * 0.2;
    meshRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.2) * 0.3;
  });

  return (
    <Sphere args={[1, 64, 64]} position={position} scale={scale} ref={meshRef}>
      <MeshDistortMaterial 
        color={color} 
        attach="material" 
        distort={distort} 
        speed={0.5} 
        roughness={0.2}
        metalness={0.8}
      />
    </Sphere>
  );
};

// Particle system for background effect
const ParticleSystem = () => {
  const particlesRef = useRef<THREE.Points>(null);
  const particleCount = 500;
  
  // Create particles geometry
  const particlesGeometry = new THREE.BufferGeometry();
  const positionArray = new Float32Array(particleCount * 3);
  
  // Randomly position particles in 3D space
  for (let i = 0; i < particleCount * 3; i++) {
    positionArray[i] = (Math.random() - 0.5) * 20;
  }
  
  particlesGeometry.setAttribute('position', new THREE.BufferAttribute(positionArray, 3));
  
  // Animate particles
  useFrame((state) => {
    if (!particlesRef.current) return;
    
    particlesRef.current.rotation.x = state.clock.elapsedTime * 0.05;
    particlesRef.current.rotation.y = state.clock.elapsedTime * 0.03;
  });
  
  return (
    <points ref={particlesRef}>
      <bufferGeometry attach="geometry" {...particlesGeometry} />
      <pointsMaterial 
        attach="material" 
        size={0.05} 
        color="#ffffff" 
        transparent 
        opacity={0.6}
        sizeAttenuation
      />
    </points>
  );
};

// Main scene component
const Scene = () => {
  const sceneRef = useRef<THREE.Group>(null);
  
  useEffect(() => {
    // Initial animation when component mounts
    if (sceneRef.current) {
      gsap.from(sceneRef.current.scale, {
        x: 0,
        y: 0,
        z: 0,
        duration: 2,
        ease: "elastic.out(1, 0.5)"
      });
    }
  }, []);
  
  return (
    <group ref={sceneRef}>
      <ParticleSystem />
      <FloatingSphere position={[-4, 2, -5]} color="#ff6b6b" speed={0.5} distort={0.4} scale={1.5} />
      <FloatingSphere position={[5, -1, -10]} color="#4ecdc4" speed={0.3} distort={0.3} scale={2} />
      <FloatingSphere position={[0, 3, -8]} color="#45b7d1" speed={0.4} distort={0.5} scale={1} />
      <FloatingSphere position={[3, -2, -6]} color="#ffffff" speed={0.2} distort={0.2} scale={0.8} />
      <Environment preset="night" />
    </group>
  );
};

// Main ThreeBackground component
const ThreeBackground = () => {
  return (
    <div className="three-background">
      <Canvas
        camera={{ position: [0, 0, 10], fov: 75 }}
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          pointerEvents: 'none',
        }}
        dpr={[1, 2]} // Optimize for performance
      >
        <Scene />
      </Canvas>
    </div>
  );
};

export default ThreeBackground;